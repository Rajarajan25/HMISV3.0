import React from "react";

export default Comp => () => (
  <div className="example-warper">
    <Comp />
  </div>
);
