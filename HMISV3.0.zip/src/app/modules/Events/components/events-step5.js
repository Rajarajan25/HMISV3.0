import React from 'react';


export default function EventStep5() {

  return (
    <div className="event-step5">
      <p>Step5</p>
    </div>
  );
}