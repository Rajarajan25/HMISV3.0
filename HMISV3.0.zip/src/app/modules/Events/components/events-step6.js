import React from 'react';


export default function EventStep6() {

  return (
    <div className="event-step6">
      <p>Step6</p>
    </div>
  );
}