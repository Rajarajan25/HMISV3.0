import React from 'react';


export default function EventStep2() {

  return (
    <div className="event-step2">
      <p>Step2</p>
    </div>
  );
}