import React from 'react';


export default function EventStep4() {

  return (
    <div className="event-step4">
      <p>Step4</p>
    </div>
  );
}