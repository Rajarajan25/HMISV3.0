import React from 'react';


export default function EventStepper6() {
  return (
    <div className="event-stepper6">
      <h3 className="stepper-title">Booking</h3>
      <p className="stepper-desc">The passage is attributed to an unknown typesetter in the 15th century who is</p>     
    </div>
  );
}
