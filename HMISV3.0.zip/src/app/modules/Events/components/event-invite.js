import React from "react";
import { Link } from "react-router-dom";
import { toAbsoluteUrl } from "../../../../_metronic/_helpers";
import { makeStyles } from '@material-ui/core/styles';
import {Button} from "react-bootstrap";
import PropTypes from 'prop-types';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';


export function ContentEventInvite() {
  return (
    <div className="clearfix">
      <div className="event_detail pb-5">
        <div className="event-height">
        ContentEventInvite
        </div>
      </div>
    </div>
  );
}