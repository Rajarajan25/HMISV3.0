import React from 'react';


export default function EventStep3() {

  return (
    <div className="event-step3">
      <p>Step3</p>
    </div>
  );
}